"""Verify this bounded research run and export reviewable evidence."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
out = root / 'docs/benchmarks/2026-09-15-ssd-streaming-ablation'
excluded = {'v4-observer': '934-token pilot did not reach layer-major threshold',
            'qwen-observer': 'pilot superseded by per-layer observer; source snapshots unavailable'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = {'evidence_kind': 'local_research_screening', 'formal_performance_result': False,
          'excluded_suites': excluded, 'full_model_suites': {}, 'layout_components': {},
          'metadata_corrections': [], 'verified_runs': 0, 'verified_runs_meaning': 'Artifact integrity only; includes rejected candidates. See comparison.valid and documented exclusions.', 'files': {}}
for p in sorted(base.glob('*/summary.json')):
    name = p.parent.name
    data = json.loads(p.read_text())
    if name in excluded:
        continue
    if data.get('evidence_kind') == 'real_weight_io_component':
        for layer in data['layers']:
            assert all(r['all_bytes_exact'] for r in layer['runs'])
            assert len({r['logical_bytes'] for r in layer['runs']}) == 1
        result['layout_components'][name] = data
    else:
        assert data['status'] == 'complete', (name, data.get('error'))
        for relative, digest in data['source']['sha256'].items():
            assert sha(p.parent / 'source' / relative) == digest, (name, relative)
        for r in data['runs']:
            m = r['metrics']
            assert sha(p.parent / f"{r['wave']}-{r['variant']}.json") == r['metrics_sha256']
            assert hashlib.sha256(','.join(map(str,m['generated_token_ids'])).encode()).hexdigest() == m['token_sha256']
            assert m['prompt_token_sha256'] == data['prompt']['token_sha256']
            if r['variant'] == 'cost_hot' and name in ('qwen-cost-screen','v4-cost-direct-screen'):
                r['effective_worker']['layer_reserve'] = 0
                r['effective_worker']['frequency_half_life_decode_tokens'] = 16
                result['metadata_corrections'].append({'suite': name, 'wave': r['wave'],
                    'reason': 'Original label said production; saved executed source uses reserve 0 and decay 16. Raw files retained.'})
            r['metrics']['combined_expert_bytes_read'] = (m['expert_bytes_read'] +
                m.get('mtp_expert_bytes_read',0) + m.get('dspark_draft_expert_bytes_read',0))
            result['verified_runs'] += 1
        result['full_model_suites'][name] = {'model': data['model'], 'prompt': data['prompt'],
            'cache_state': data['cache_state'], 'comparison': data['comparison'],
            'run_count': len(data['runs']), 'file': f'{name}.json'}
    (out / f'{name}.json').write_text(json.dumps(data,indent=2)+'\n')
for model in ('v4','qwen'):
    for filename in ('decode-layers.csv', '0-control.route.json.layers.json'):
        (out / f'{model}-{filename}').write_text((base / f'{model}-layers' / filename).read_text())
    shutil.copyfile(base / f'{model}-layout-plan.json', out / f'{model}-layout-plan.json')
archive = out / 'raw-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.suffix != '.bin' and '.trace' not in str(p) and p.name != 'qwen-gpu-intervals.xml':
            tar.add(p, arcname=str(p.relative_to(base)))
for p in sorted(out.iterdir()):
    if p.is_file() and p.name not in ('summary.json','README.md'):
        result['files'][p.name] = {'sha256': sha(p), 'bytes': p.stat().st_size}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified',result['verified_runs'],'full-model/observer runs;',len(result['layout_components']),'component suites')
