"""Experimental readers; never imported by the app or normal CLI."""
from __future__ import annotations

import mmap
import os
import threading
import time
from contextlib import contextmanager


def aligned_read(fd, offset, length, buffer, alignment=mmap.PAGESIZE):
    """Read a canonical range with aligned I/O, including a partial EOF page."""
    if offset < 0 or length < 1 or alignment < 1:
        raise ValueError("invalid read range or alignment")
    begin = offset // alignment * alignment
    prefix = offset - begin
    size = (prefix + length + alignment - 1) // alignment * alignment
    if len(buffer) < size:
        raise ValueError("aligned read buffer is too small")
    view = memoryview(buffer)[:size]
    done = 0
    try:
        while done < prefix + length:
            count = os.preadv(fd, [view[done:]], begin + done)
            if count <= 0:
                raise EOFError(f"short aligned read at {begin + done}")
            done += count
            if done < prefix + length and done % alignment:
                if begin + done >= os.fstat(fd).st_size:
                    raise EOFError(f"requested range extends past EOF at {begin + done}")
                raise OSError("unaligned short read before requested range completed")
    finally:
        view.release()
    return prefix


def install_split_io():
    import mlx.core as mx
    from deepseek_v4_ssd.cancellation import check_cancelled
    from deepseek_v4_ssd.expert_cache import ExpertCache, _SpeculativeRead
    from deepseek_v4_ssd.io_metrics import configure_expert_file_cache_policy
    original_init, original_close = ExpertCache.__init__, ExpertCache.close

    def initialize(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self._ablation_prefill_fds = []
        self._ablation_buffers = threading.local()
        try:
            for layer in range(self.layer_count):
                fd = os.open(self.expert_directory / f"layer_{layer:02d}.bin", os.O_RDONLY)
                self._ablation_prefill_fds.append(fd)
                configure_expert_file_cache_policy(fd, "bypass")
        except BaseException:
            close(self)
            raise

    def close(self):
        try:
            original_close(self)
        finally:
            for fd in self._ablation_prefill_fds:
                os.close(fd)
            self._ablation_prefill_fds = []

    def read_ids(self, layer, packed, experts):
        started = time.perf_counter()
        blob = self.model.expert_blob_size
        local = self._ablation_buffers
        if not hasattr(local, "buffer"):
            local.buffer = mmap.mmap(-1, blob + 2 * mmap.PAGESIZE)
        target = memoryview(packed).cast("B")
        source = memoryview(local.buffer)
        try:
            for expert in experts:
                check_cancelled()
                cursor = aligned_read(self._ablation_prefill_fds[layer], expert * blob,
                                      blob, local.buffer)
                views = self._pool.write_views(target, expert)
                try:
                    for view in views:
                        view[:] = source[cursor:cursor + len(view)]
                        cursor += len(view)
                finally:
                    for view in views:
                        view.release()
        finally:
            source.release()
            target.release()
        return _SpeculativeRead(started, time.perf_counter())

    ExpertCache.__init__, ExpertCache.close = initialize, close
    ExpertCache._read_expert_ids = read_ids


def install_adaptive():
    """V4 uses the existing planner; Qwen lazily fills required canonical rows.

    Qwen retains all previously filled rows of the current layer across chunks.
    Its original gather operations and indices remain unchanged.
    """
    import mlx.core as mx
    import numpy as np
    from deepseek_v4_ssd import cli
    from deepseek_v4_ssd.expert_cache import ExpertCache, _SpeculativeRead
    from deepseek_v4_ssd.qwen4_exp import StreamingExperts
    from deepseek_v4_ssd.manifest import InstalledModel
    from deepseek_v4_ssd.cancellation import check_cancelled

    original_config = cli.RuntimeConfig
    def config(**kwargs):
        # CLI dispatches after parsing; model kind is available from --model.
        import sys
        path = sys.argv[sys.argv.index("--model") + 1]
        installed = InstalledModel.open(path)
        if installed.model_kind == "deepseek-v4":
            kwargs["adaptive_expert_prefill_threshold"] = 0.8
        return original_config(**kwargs)
    cli.RuntimeConfig = config
    original_batched = ExpertCache.batched_layer
    original_call = StreamingExperts.__call__

    @contextmanager
    def batched_layer(self, layer, enabled=True, experts=None, adaptive=False):
        if not self.model.is_qwen or not enabled:
            with original_batched(self, layer, enabled, experts, adaptive) as result:
                yield result
            return
        self._ablation_pending_layer = layer
        self._ablation_filled = set()
        length = self.model.expert_count * self.model.expert_blob_size
        packed = mx.empty((length // 4,), dtype=mx.uint32)
        mx.eval(packed)
        self._ablation_packed = packed
        self._batched_layer = (layer, self._pool.batched(packed))
        self.metrics.batched_layers += 1
        try:
            yield self._batched_layer[1]
        finally:
            self._batched_layer = None
            self._ablation_pending_layer = None
            self._ablation_packed = None

    def call(self, value, indices):
        cache = self.cache
        if getattr(cache, "_ablation_pending_layer", None) == self.layer:
            check_cancelled()
            started = time.perf_counter()
            selected = set(np.asarray(indices, dtype=np.int32).reshape(-1).tolist())
            filled = cache._ablation_filled
            missing = selected - filled
            full = len(selected | filled) / cache.model.expert_count > 0.8
            if full:
                missing = set(range(cache.model.expert_count)) - filled
            cache.metrics.adaptive_prefill_plan_seconds += time.perf_counter() - started
            if missing:
                chosen = tuple(sorted(missing))
                step = (len(chosen) + cache.prefetch_read_workers - 1) // cache.prefetch_read_workers
                jobs = [cache._executor.submit(cache._read_expert_ids, self.layer,
                         cache._ablation_packed, chosen[i:i + step])
                        for i in range(0, len(chosen), step)]
                # Drain all workers before buffer lifetime can end on failure.
                from deepseek_v4_ssd.cancellation import wait_for_futures
                reads = wait_for_futures(jobs)
                count = len(chosen) * cache.model.expert_blob_size
                cache.metrics.bytes_read += count
                cache.metrics.adaptive_prefill_bytes_read += count
                cache.metrics.read_seconds += max(r.finished - r.started for r in reads)
                filled.update(chosen)
            return original_call(self, value, indices)
        return original_call(self, value, indices)

    ExpertCache.batched_layer = batched_layer
    StreamingExperts.__call__ = call
