"""Native-weight checks for research-only reader and union patches."""
import hashlib
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import mlx.core as mx
from deepseek_v4_ssd.expert_cache import ExpertCache
from deepseek_v4_ssd.qwen4_exp import SparseMoE
from runtime.tests.test_qwen_resident_block import fixture
from research.ssd_streaming_candidates import install_split_io
from research.ssd_streaming_speculation import install_qwen_union
from research.ssd_streaming_hotness import install_cost_hotness
from research.ssd_streaming_contiguous import install_contiguous


class StreamingCandidateTests(unittest.TestCase):
    def test_qwen_contiguous_prefill_can_bypass_without_staging_and_stays_byte_exact(self):
        from contextlib import ExitStack
        for bypass in (False, True):
            with ExitStack() as stack, tempfile.TemporaryDirectory() as directory:
                for name in ("__init__", "close", "_read_expert_ids"):
                    stack.enter_context(patch.object(ExpertCache, name, getattr(ExpertCache, name)))
                model = fixture(Path(directory))
                install_contiguous(bypass)
                with ExpertCache(model, slots=12, prefetch_read_workers=1) as cache:
                    with cache.batched_layer(0, experts=list(range(8))):
                        packed = memoryview(cache._active_prefetch_trace.job.packed).cast("B")
                        try:
                            source = (model.root / "experts/layer_00.bin").read_bytes()
                            self.assertEqual(bytes(packed[:8 * model.expert_blob_size]), source[:8 * model.expert_blob_size])
                        finally:
                            packed.release()
                    self.assertEqual(cache._ablation_direct, 8)
                    self.assertEqual(getattr(cache, "_ablation_copied", 0), 0)

    def test_cost_hotness_rebuilds_prices_without_stale_heap_entries(self):
        from runtime.tests.test_expert_eviction_policy import fixture as small_fixture
        from contextlib import ExitStack
        methods = ("__init__", "_touch", "_eviction_rank", "_decay_if_needed", "_read_expert_into_pool")
        with ExitStack() as stack, tempfile.TemporaryDirectory() as directory:
            for name in methods:
                stack.enter_context(patch.object(ExpertCache, name, getattr(ExpertCache, name)))
            model = small_fixture(Path(directory), layers=2)
            install_cost_hotness()
            with ExpertCache(model, slots=4) as cache:
                cache.get_many(0, [0, 1])
                cache.get_many(1, [0, 1])
                cache._cost_sum = [1.0, 4.0]
                cache._cost_count = [1, 1]
                cache._clock = 32
                cache._decay_if_needed()
                self.assertLess(cache._cost_active[0], cache._cost_active[1])
                self.assertEqual(cache._layer_reserve, 0)
                self.assertEqual(len(cache._heap), cache.resident_count)
                cache.get_many(1, [2])
                self.assertEqual(cache.resident_count, 4)
                self.assertTrue(all(item[0] == cache._eviction_rank(cache._entries[(item[3], item[4])])
                                    for item in cache._heap if (item[3], item[4]) in cache._entries and
                                    item[2] == cache._entries[(item[3], item[4])].version))

    def test_split_prefill_handles_qwen_unaligned_blobs_and_decode_reuses_cached_reader(self):
        original = (ExpertCache.__init__, ExpertCache.close, ExpertCache._read_expert_ids)
        with patch.object(ExpertCache, "__init__", original[0]), \
                patch.object(ExpertCache, "close", original[1]), \
                patch.object(ExpertCache, "_read_expert_ids", original[2]), tempfile.TemporaryDirectory() as directory:
            model = fixture(Path(directory))
            install_split_io()
            with ExpertCache(model, slots=12) as cache:
                self.assertEqual(cache.file_cache_policy, "cached")
                self.assertNotEqual(cache._descriptors, cache._ablation_prefill_fds)
                with cache.batched_layer(0, experts=[0, 1, 11]):
                    job = cache._batched_layer[1]
                    mx.eval(job.gate_up, job.down)
                    packed = memoryview(cache._active_prefetch_trace.job.packed).cast("B")
                    source = (model.root / "experts/layer_00.bin").read_bytes()
                    try:
                        for expert in (0, 1, 11):
                            views = cache._pool.write_views(packed, expert)
                            actual = b"".join(bytes(view) for view in views)
                            for view in views:
                                view.release()
                            self.assertEqual(actual, source[expert * model.expert_blob_size:(expert + 1) * model.expert_blob_size])
                    finally:
                        packed.release()
                cache.get_many(0, [1, 11])
                self.assertEqual(cache.metrics.bytes_read, 5 * model.expert_blob_size)
                source = (model.root / "experts/layer_00.bin").read_bytes()
                for expert in (1, 11):
                    slot = cache._entries[(0, expert)].slot
                    actual = bytes(cache._pool._views[slot])
                    expected = source[expert * model.expert_blob_size:(expert + 1) * model.expert_blob_size]
                    self.assertEqual(hashlib.sha256(actual).digest(), hashlib.sha256(expected).digest())

    def test_qwen_union_prefetch_keeps_block_output_exact_and_closes_scratch(self):
        original_init, original_call = ExpertCache.__init__, SparseMoE.__call__
        with tempfile.TemporaryDirectory() as directory:
            model = fixture(Path(directory))
            args = SimpleNamespace(hidden_size=2560, num_experts=12,
                                   shared_expert_intermediate_size=8,
                                   num_experts_per_tok=4, norm_topk_prob=True)
            with ExpertCache(model, slots=12) as control:
                moe = SparseMoE(args, 0, control)
                value = mx.ones((1, 3, 2560), mx.bfloat16) * 0.125
                expected = moe(value)
                mx.eval(expected)
                with patch.object(ExpertCache, "__init__", original_init), patch.object(SparseMoE, "__call__", original_call):
                    install_qwen_union()
                    with ExpertCache(model, slots=12) as candidate:
                        moe.cache = candidate
                        moe.experts.cache = candidate
                        actual = moe(value)
                        self.assertTrue(mx.array_equal(expected, actual).item())
                        self.assertIsNone(candidate._active_speculative_prefetch)
                        self.assertFalse(candidate._speculative_pinned_keys)
                        self.assertEqual(candidate.metrics.speculative_prefetch_rounds, 1)


if __name__ == "__main__":
    unittest.main()
