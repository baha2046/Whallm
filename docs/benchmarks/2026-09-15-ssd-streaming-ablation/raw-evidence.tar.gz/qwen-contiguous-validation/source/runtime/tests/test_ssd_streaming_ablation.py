from __future__ import annotations

import mmap
import os
import tempfile
import unittest

from research.ssd_streaming_ablation import summarize
from research.ssd_streaming_candidates import aligned_read
from research.ssd_streaming_layout import learn_order, groups
from research.ssd_streaming_layout_io import repack, read_group
from pathlib import Path


class StreamingAblationTests(unittest.TestCase):
    def test_aligned_read_handles_unaligned_expert_and_partial_eof(self):
        data = bytes(range(251)) * 173
        with tempfile.TemporaryFile() as file, mmap.mmap(-1, 65536) as buffer:
            file.write(data)
            file.flush()
            for offset, length in ((0, 100), (8191, 15000), (32769, len(data) - 32769)):
                prefix = aligned_read(file.fileno(), offset, length, buffer)
                self.assertEqual(buffer[prefix:prefix + length], data[offset:offset + length])
            with self.assertRaises(EOFError):
                aligned_read(file.fileno(), len(data), 100, buffer)
            with self.assertRaises(ValueError):
                aligned_read(file.fileno(), 0, 100000, buffer)

    def test_speed_signal_rejects_changed_output_swap_and_excess_memory(self):
        def row(wave, variant):
            return {"wave": wave, "variant": variant, "swapout_delta": 0,
                    "metrics": {"token_sha256": "same", "request_seconds": 10 if variant == "control" else 8,
                                "time_to_first_token_seconds": 5, "decode_tokens_per_second": 10 if variant == "control" else 12,
                                "expert_bytes_read": 100, "peak_memory_bytes": 200}}
        rows = [row(wave, mode) for wave in range(2) for mode in ("control", "dynamic")]
        self.assertTrue(summarize(rows)["variants"]["dynamic"]["screening_speed_signal"])
        for key, value in (("token_sha256", "different"), ("peak_memory_bytes", 2_000_000_000)):
            original = rows[1]["metrics"][key]
            rows[1]["metrics"][key] = value
            self.assertFalse(summarize(rows)["variants"]["dynamic"]["screening_speed_signal"])
            rows[1]["metrics"][key] = original
        rows[1]["swapout_delta"] = 1
        self.assertFalse(summarize(rows)["variants"]["dynamic"]["screening_speed_signal"])

    def test_one_pair_is_not_a_speed_signal(self):
        self.assertEqual(summarize([]), {"pairs": [], "variants": {}})

    def test_coactivation_repack_preserves_logical_ids_and_exact_bytes(self):
        order = learn_order([[0, 2], [0, 2], [1, 3]], 4)
        self.assertEqual(sorted(order), list(range(4)))
        self.assertEqual(len(groups([0, 2], order)), 1)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, target = root / "source", root / "target"
            blob = 7
            source.write_bytes(b"".join(bytes([x]) * blob for x in range(4)))
            hashes = repack(source, target, order, blob)
            buffers = {x: bytearray(blob) for x in range(4)}
            fd = os.open(target, os.O_RDONLY)
            try:
                read_group(fd, buffers, order, {x: i for i, x in enumerate(order)}, blob)
            finally:
                os.close(fd)
            for x in range(4):
                self.assertEqual(buffers[x], bytes([x]) * blob)
            self.assertEqual(len(hashes), 4)
            with self.assertRaises(ValueError):
                repack(source, root / "bad", [0, 0, 1, 2], blob)


if __name__ == "__main__":
    unittest.main()
