"""Qwen's full Prefill batches are contiguous and can be read without staging."""
import ctypes
import mmap
import os
import time
import json
import sys
from pathlib import Path


def install_contiguous(bypass):
    from deepseek_v4_ssd.expert_cache import ExpertCache, _SpeculativeRead
    if bypass:
        if __package__:
            from .ssd_streaming_candidates import install_split_io_direct
        else:
            from ssd_streaming_candidates import install_split_io_direct
        install_split_io_direct()
    fallback = ExpertCache._read_expert_ids
    close = ExpertCache.close

    def read(self, layer, packed, experts):
        # Qwen canonical and slot layouts are identical; V4 needs scatter layout.
        if (not self.model.is_qwen or not experts or
                experts != tuple(range(experts[0], experts[-1] + 1))):
            return fallback(self, layer, packed, experts)
        offset = experts[0] * self.model.expert_blob_size
        length = len(experts) * self.model.expert_blob_size
        view = memoryview(packed).cast("B")[offset:offset + length]
        if bypass and (offset % mmap.PAGESIZE or length % mmap.PAGESIZE or
                       ctypes.addressof(ctypes.c_char.from_buffer(view)) % mmap.PAGESIZE):
            view.release()
            return fallback(self, layer, packed, experts)
        started = time.perf_counter()
        fd = self._ablation_prefill_fds[layer] if bypass else self._descriptors[layer]
        done = 0
        try:
            while done < length:
                count = os.preadv(fd, [view[done:]], offset + done)
                if count <= 0:
                    raise EOFError("short contiguous Prefill read")
                done += count
                if bypass and done < length and done % mmap.PAGESIZE:
                    raise OSError("unaligned partial contiguous read")
        finally:
            view.release()
        with self._lock:
            self._ablation_direct = getattr(self, "_ablation_direct", 0) + len(experts)
            self._ablation_contiguous_calls = getattr(self, "_ablation_contiguous_calls", 0) + 1
        return _SpeculativeRead(started, time.perf_counter())

    def finish(self):
        close(self)
        if "--metrics-json" in sys.argv:
            path = Path(sys.argv[sys.argv.index("--metrics-json") + 1] + ".reader.json")
            path.write_text(json.dumps({"direct_prefill_experts": getattr(self, "_ablation_direct", 0),
                "staged_copy_prefill_experts": getattr(self, "_ablation_copied", 0),
                "contiguous_prefill_calls": getattr(self, "_ablation_contiguous_calls", 0)}) + "\n")

    ExpertCache._read_expert_ids, ExpertCache.close = read, finish
