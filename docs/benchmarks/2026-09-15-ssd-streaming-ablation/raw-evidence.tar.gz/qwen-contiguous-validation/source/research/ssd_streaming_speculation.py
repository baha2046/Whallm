"""Qwen MTP route-union prefetch experiment, using existing scratch ownership."""


def install_qwen_sequential_verifier():
    import mlx.core as mx
    from deepseek_v4_ssd.qwen4_exp import Model
    original = Model.forward_with_hidden

    def forward(self, input_ids, cache=None):
        if 2 <= input_ids.shape[1] <= 6:
            logits, hidden = [], []
            for i in range(input_ids.shape[1]):
                prediction, state = original(self, input_ids[:, i:i + 1], cache)
                # Match ordinary one-token state updates before the next position.
                from deepseek_v4_ssd.model import eval_prompt_cache
                eval_prompt_cache(cache, prediction, state)
                logits.append(prediction)
                hidden.append(state)
            return mx.concatenate(logits, axis=1), mx.concatenate(hidden, axis=1)
        return original(self, input_ids, cache)

    Model.forward_with_hidden = forward


def install_qwen_union():
    import mlx.core as mx
    import numpy as np
    from deepseek_v4_ssd.qwen4_exp import SparseMoE
    from deepseek_v4_ssd.expert_cache import ExpertCache

    original_init, original_call = ExpertCache.__init__, SparseMoE.__call__

    def initialize(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        # Only target cache, not the separate one-layer MTP cache.
        if self.model.is_qwen and self.layer_count == self.model.layer_count:
            self.configure_speculative_scratch(6 * self.model.selected_expert_count)

    def call(self, value):
        positions = value.size // value.shape[-1]
        if (self.cache.layer_count != self.cache.model.layer_count or
                not (2 <= positions <= 6) or self.cache.current_batched(self.layer) is not None):
            return original_call(self, value)
        probabilities = mx.softmax(self.gate(value), axis=-1, precise=True)
        indices = mx.argpartition(probabilities, kth=-self.top_k, axis=-1)[..., -self.top_k:]
        scores = mx.take_along_axis(probabilities, indices, axis=-1)
        if self.norm_topk_prob:
            scores = scores / scores.sum(axis=-1, keepdims=True)
        selected = np.asarray(indices, dtype=np.int32)
        union = sorted(set(selected.reshape(-1).tolist()))
        with self.cache.speculative_prefetch({self.layer: union}):
            shared = mx.sigmoid(self.shared_expert_gate(value)) * self.shared_expert(value)
            mx.async_eval(shared)
            routed = self.experts(value, indices)
            routed = (routed * scores[..., None].astype(routed.dtype)).sum(axis=-2)
            result = routed + shared
            # The scratch pool may be overwritten by the next layer only after consumption.
            mx.eval(result)
        return result

    ExpertCache.__init__, SparseMoE.__call__ = initialize, call
