"""Learn an expert file permutation from past routes and test held-out reads."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path


def learn_order(routes, expert_count):
    weights = [dict() for _ in range(expert_count)]
    for route in routes:
        for a, b in itertools.combinations(sorted(set(route)), 2):
            weights[a][b] = weights[a].get(b, 0) + 1
            weights[b][a] = weights[b].get(a, 0) + 1
    degree = [sum(row.values()) for row in weights]
    remaining = set(range(expert_count))
    current = max(remaining, key=lambda x: (degree[x], -x))
    order = []
    while remaining:
        order.append(current)
        remaining.remove(current)
        if remaining:
            current = max(remaining, key=lambda x: (weights[current].get(x, 0), degree[x], -x))
    return order


def groups(experts, order):
    positions = {expert: position for position, expert in enumerate(order)}
    selected = sorted(set(experts), key=positions.__getitem__)
    result = []
    for expert in selected:
        if result and positions[expert] == positions[result[-1][-1]] + 1:
            result[-1].append(expert)
        else:
            result.append([expert])
    return result


def analyze(trace):
    layers = []
    count = trace["expert_count"]
    for layer, routes in enumerate(trace["decode_routes"]):
        split = len(routes) // 2
        if not split:
            raise ValueError("need both training and held-out routes")
        order = learn_order(routes[:split], count)
        masks = trace["decode_misses"][layer]
        if len(masks) != len(routes):
            raise ValueError("route/miss count mismatch")
        queries = [[expert for expert, miss in zip(route, mask) if miss]
                   for route, mask in zip(routes[split:], masks[split:])]
        baseline = sum(len(groups(q, list(range(count)))) for q in queries)
        candidate = sum(len(groups(q, order)) for q in queries)
        reads = sum(len(q) for q in queries)
        layers.append({"layer": layer, "train_tokens": split, "heldout_tokens": len(queries),
                       "order": order, "queries": queries, "individual_reads": reads,
                       "identity_coalesced_calls": baseline, "learned_coalesced_calls": candidate,
                       "logical_bytes": reads * trace["expert_blob_size"]})
    baseline = sum(r["identity_coalesced_calls"] for r in layers)
    candidate = sum(r["learned_coalesced_calls"] for r in layers)
    return {"evidence_kind": "heldout_route_layout_screen", "layers": layers,
            "identity_coalesced_calls": baseline, "learned_coalesced_calls": candidate,
            "call_reduction_percent": 100 * (1 - candidate / baseline) if baseline else 0,
            "logical_byte_change_percent": 0,
            "limits": ["First-half training; second-half testing from the same request, not independent workload validation.",
                       "Uses recorded baseline cache misses; does not simulate a new cache policy.",
                       "Call reduction is not measured latency or physical SSD traffic.",
                       "No gap over-read: adjacent selected experts only."]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(json.loads(args.trace.read_text()))
    result["trace_sha256"] = hashlib.sha256(args.trace.read_bytes()).hexdigest()
    result["source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "layers"}, indent=2))
