"""Physical co-activation repack and equal-byte, real-weight I/O comparison."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import fcntl
import mmap
import statistics
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

if __package__:
    from .ssd_streaming_layout import groups
else:
    from ssd_streaming_layout import groups


def repack(source, destination, order, blob, bypass=False):
    """Write a separate file; never modify the installed model."""
    if len(order) != len(set(order)) or sorted(order) != list(range(len(order))):
        raise ValueError("layout must be a permutation")
    if source.stat().st_size != len(order) * blob:
        raise ValueError("source size does not match layout")
    hashes = {}
    with source.open("rb") as src, destination.open("xb") as dst:
        if bypass:
            fcntl.fcntl(dst.fileno(), fcntl.F_NOCACHE, 1)
        for expert in order:
            src.seek(expert * blob)
            data = src.read(blob)
            if len(data) != blob:
                raise EOFError("short expert during repack")
            dst.write(data)
            hashes[expert] = hashlib.sha256(data).hexdigest()
        dst.flush()
        os.fsync(dst.fileno())
    return hashes


def read_group(fd, buffers, group, positions, blob):
    views = [memoryview(buffers[expert]) for expert in group]
    offset = positions[group[0]] * blob
    try:
        pending = list(views)
        while pending:
            count = os.preadv(fd, pending, offset)
            if count <= 0:
                raise EOFError("short coalesced expert read")
            offset += count
            while pending and count >= len(pending[0]):
                count -= len(pending.pop(0))
            if pending and count:
                pending[0] = pending[0][count:]
    finally:
        for view in views:
            view.release()


def run(model, plan_path, output, layers, bypass=False):
    output.mkdir(parents=True, exist_ok=False)
    plan = json.loads(plan_path.read_text())
    manifest = json.loads((model / "manifest.json").read_text())
    blob = manifest["expertBlobSize"]
    results = []
    for index in layers:
        row = plan["layers"][index]
        source = model / "experts" / f"layer_{index:02d}.bin"
        destination = output / source.name
        started = time.perf_counter()
        hashes = repack(source, destination, row["order"], blob, bypass)
        install_seconds = time.perf_counter() - started
        identity = list(range(manifest["expertCount"]))
        if bypass:
            identity_file = output / f"identity_{index:02d}.bin"
            repack(source, identity_file, identity, blob, True)
            source = identity_file
        runs = []
        fds = {"individual": os.open(source, os.O_RDONLY),
               "identity": os.open(source, os.O_RDONLY),
               "learned": os.open(destination, os.O_RDONLY)}
        try:
            if bypass:
                for fd in fds.values():
                    fcntl.fcntl(fd, fcntl.F_NOCACHE, 1)
                    fcntl.fcntl(fd, fcntl.F_RDAHEAD, 0)
            local = threading.local()
            def read_bypassed(fd, buffers, group, positions, blob):
                if __package__:
                    from .ssd_streaming_candidates import aligned_read
                else:
                    from ssd_streaming_candidates import aligned_read
                if not hasattr(local, "buffer"):
                    local.buffer = mmap.mmap(-1, manifest["selectedExpertCount"] * blob + 2 * mmap.PAGESIZE)
                cursor = aligned_read(fd, positions[group[0]] * blob, len(group) * blob, local.buffer)
                view = memoryview(local.buffer)
                try:
                    for expert in group:
                        buffers[expert][:] = view[cursor:cursor + blob]
                        cursor += blob
                finally:
                    view.release()
            with ThreadPoolExecutor(max_workers=4) as executor:
                for wave in range(2):
                    for mode in (("individual", "identity", "learned") if wave == 0 else
                                 ("learned", "identity", "individual")):
                        order = row["order"] if mode == "learned" else identity
                        positions = {expert: i for i, expert in enumerate(order)}
                        residency = None
                        if bypass:
                            from deepseek_v4_ssd.io_metrics import page_cache_residency_snapshot
                            sample = page_cache_residency_snapshot(fds[mode], 0, manifest["expertCount"] * blob)
                            residency = (sample.classify(manifest["expertCount"] * blob).resident_bytes
                                         if sample else None)
                        elapsed = 0
                        calls = 0
                        byte_count = 0
                        query_times = []
                        for query in row["queries"]:
                            if not query:
                                continue
                            buffers = {expert: bytearray(blob) for expert in query}
                            batches = [[x] for x in sorted(set(query))] if mode == "individual" else groups(query, order)
                            start = time.perf_counter()
                            jobs = [executor.submit(read_bypassed if bypass else read_group, fds[mode], buffers, group,
                                                    positions, blob) for group in batches]
                            for job in jobs:
                                job.result()
                            duration = time.perf_counter() - start
                            elapsed += duration
                            query_times.append(duration)
                            calls += len(batches)
                            byte_count += len(query) * blob
                            for expert, data in buffers.items():
                                if hashlib.sha256(data).hexdigest() != hashes[expert]:
                                    raise ValueError("repacked expert differs from canonical bytes")
                        runs.append({"wave": wave, "mode": mode, "read_seconds": elapsed,
                                     "read_calls": calls, "logical_bytes": byte_count,
                                     "file_resident_bytes_before_run": residency,
                                     "query_seconds": query_times, "all_bytes_exact": True})
                        print(f"layer={index} wave={wave} {mode}: {elapsed:.3f}s / {calls} reads", flush=True)
        finally:
            for fd in fds.values():
                os.close(fd)
        medians = {mode: statistics.median(r["read_seconds"] for r in runs if r["mode"] == mode)
                   for mode in ("individual", "identity", "learned")}
        results.append({"layer": index, "repack_seconds": install_seconds,
                        "learned_vs_individual_time_percent": 100 * (medians["learned"] / medians["individual"] - 1),
                        "learned_vs_identity_time_percent": 100 * (medians["learned"] / medians["identity"] - 1),
                        "runs": runs, "repacked_file": str(destination)})
        (output / "summary.json").write_text(json.dumps({
            "evidence_kind": "real_weight_io_component", "formal_performance_result": False,
            "manifest_sha256": hashlib.sha256((model / "manifest.json").read_bytes()).hexdigest(),
            "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "file_cache_policy": "bypass" if bypass else "cached",
            "layers": results,
            "limits": ["Bypass uses separately written files and records file residency; cached mode is warm after repack.",
                       "Bypass includes an aligned staging copy for both control and candidate; not the production reader.",
                       "Four read workers; waits for complete batch. Does not model early-ready GPU overlap.",
                       "Hash validation and allocation outside measured read time.",
                       "Component timing does not establish full-model generation speed."]}, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--layers", default="12,32")
    parser.add_argument("--bypass", action="store_true")
    args = parser.parse_args()
    run(args.model.expanduser(), args.plan, args.output, [int(x) for x in args.layers.split(",")], args.bypass)
